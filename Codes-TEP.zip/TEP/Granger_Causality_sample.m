function [variable_osi, no_cause_xy] = Granger_Causality_sample (X1, Y1, kn, alpha, max_lag, l, gamma_w, gamma_beta, gamma_delta, s, d)

[n,m] = size(X1); p = size(Y1,2);

%% ———— OSI ————
% ———— DALVR ————
g = max(s,d); 

[P1, Q, C, W, Beta, Delta, Y1_debug] = darlvr(X1,Y1,l,gamma_w,gamma_beta,gamma_delta,s,d);
T1 = X1 * P1;
Lambda = 1/(n-1) * T1'* T1;

for i = 1:m
    for j = 1:l
        osi_j(i,j) = Lambda(j,j) * (sum(P1(i,:))).^2;
    end
    osi(i) = sum(osi_j(i,:));
end
[max_osi,variable_osimax] = max(osi);
control_limit = max_osi / 3;

figure;
bar(osi, 'b');   
hold on
plot(control_limit * ones(1,m))
hold all
title('OSI');   
xlabel('No. of Variables'); 

variable_osi = zeros(0,0);
for i = 1:m
    if osi(i) > max_osi/3
        variable_osi = [variable_osi i];
    end
end


%% ———— Granger Causality Between X and Y ————
no_cause_xy = zeros(m,p);
F = zeros(m,p); c_v = zeros(m,p);

for i = 1:m
    for j = 1:p
        x = X1(kn,i); 
        y = Y1(kn,j);
        [F(i,j),c_v(i,j)] = granger_causality(y,x, alpha,max_lag, l, gamma_w, gamma_beta, gamma_delta, s, d);
        if F(i,j) > c_v(i,j)
            no_cause_xy(i,j) = 1;
        end
        
    end
end

for j = 1:p
    cause_variable = zeros(0,0);
    for i = 1:m
        if no_cause_xy(i,j) == 0
            variable(j) = i;
            cause_variable = [cause_variable variable];
        end
    end
    % str = ['Variables X ', num2str(cause_variable), ' cause Y',num2str(j)];
    % disp(str)
end

%% ———— Granger Causality Among X ————
C = nchoosek(variable_osi,2); % 210 2

no_cause_x1 = zeros(1,size(C,1)); no_cause_x2 = zeros(1,size(C,1));
for k = 1:size(C,1)
    a = C(k,1); b = C(k,2);    
    x = X1(kn,a); y = X1(kn,b);
    
    [F1(k),c_v1(k)] = granger_causality(y,x,alpha,max_lag, l, gamma_w, gamma_beta, gamma_delta, s, d); % effect cause
    if F1(k) > c_v1(k)
        no_cause_x1(k) = 1;
    end
    
    [F2(k),c_v2(k)] = granger_causality(x,y,alpha,max_lag, l, gamma_w, gamma_beta, gamma_delta, s, d);
    if F2(k) > c_v2(k)
        no_cause_x2(k) = 1;
    end
        
end


%figure;
%pgon = nsidedpoly(size(variable_osi,2));
%plot(pgon)
%axis equal

% variable # = 3
%xn = [0,-0.866025,0.866025]; 
%yn = [1,-0.5,-0.5];

% variable # = 4
%xn = [-0.707107,-0.707107,0.707107,0.707107]; 
%yn = [0.707107,-0.707107,-0.707107,0.707107];

% variable # = 6
xn = [-0.5, -1, -0.5, 0.5, 1, 0.5]; 
yn = [0.866025, 0, -0.866025, -0.866025, 0, 0.866025];

% variable # = 8
%xn = [-0.382683,-0.92388,-0.92388,-0.382683,0.382683,0.92388,0.92388,0.382683]; 
%yn = [0.92388,0.382683,-0.382683,-0.92388,-0.92388,-0.382683,0.382683,0.92388];

% variable # = 12
%xn = [-0.258819,-0.707107,-0.965926,-0.965926,-0.707107,-0.258819,0.258819,0.707107,0.965926,0.965926,0.707107,0.258819]; 
%yn = [0.965926,0.707107,0.258819,-0.258819,-0.707107,-0.965926,-0.965926,-0.707107,-0.258819,0.258819,0.707107,0.965926];

% ———— Causality_map ————
figure
for k = 1:size(C,1)
    a0 = C(k,1); b0 = C(k,2);
    for i = 1:length(variable_osi)
        if a0 == variable_osi(i)
            a1 = i;
        end
        if b0 == variable_osi(i)
            b1 = i;
        end
    end    

    if no_cause_x1(k) == 0        
        c1 = [xn(a1) xn(b1)]; c2 = [yn(a1) yn(b1)];
        line(c1, c2,'Color','red','LineStyle','--')
        %annotation('arrow',c1, c2,'Color','red','LineStyle','--')
        axis equal
    end
    
    if no_cause_x2(k) == 0
        c1 = [xn(b1) xn(a1)];
        c2 = [yn(b1) yn(a1)];
        line(c1, c2,'Color','blue','LineStyle','--')
        axis equal
    end
end



%% ———— Plotting ————
%X_tag = zeros(m,1);
%for i = 1:m
%    X_tag(i) = i;
%end

%for j = 1:p
%    figure;
%    histogram(F(:,j),m);
%    bar(X_tag,F(:,j),'b');    
%    hold all
%    title('Distribution of F');    
%    xlabel('No. of Variables');  
%    ylabel('F');
%end

%figure;
%bar(osi, 'b');   
%hold on
%plot(control_limit * ones(1,m))
%hold all
%title('OSI');   
%xlabel('No. of Variables'); 


xf = [1 2 3 4 5 6]; % number of osi_variables
yf_0 = [-1 0 -1 1 0 1];
yf = zeros(1,length(variable_osi));
for i = 1 : length(variable_osi)
    osi_f(i) = osi(variable_osi(i)) / osi(variable_osimax);
    yf(i) = osi_f(i) * yf_0(i);
end

% weighted causal flows
figure;
bar(xf, yf, 'b');  
set(gca, 'xticklabel', {'7','11','13','16','18','27'})
hold all
title('Causal Flow of Variables');    
xlabel('No. of Variables');  

% traditional causal flows
figure;
bar(xf, yf_0, 'b');  
set(gca, 'xticklabel', {'7','11','13','16','18','27'})
hold all
title('Causal Flow of Variables');    
xlabel('No. of Variables');  
