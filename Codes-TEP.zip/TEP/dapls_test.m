function [T2_index,Tc2_index,Tdy2_index,Tsy2_index,Qy_index,phi_dx_index,Tsx2_index,Qsx_index,Qdx_index] = dapls_test(X1_test,Y1_test,...,
    a,s,d,R,Q,Alpha,P,W,C,Gama,Rc,Rx,Theta_x,Qc,Py,P_dx,P_sx,Lambda,Lambda_c,Lambda_dy,Lambda_sy,Lambda_sx,Phi_dx)

[n,m] = size(X1_test); np = size(Y1_test,2);
g = max(s,d); N = n - g;

% Predictable output
Yh_xg = zeros(N,np); 
for i = 1:a
    for j = 0:s
        Yh_xg = Yh_xg + Alpha(j+1,i)*X1_test(g+1-j:n-j,:)*R*C';
    end     
end
% Yh_xg = (Zx*kron(alpha,R))*C'; % process-quality / predictable output

% Auto-regressive quality part
Yh_yg = zeros(N,np);
for i = 1:a
    for j = 1:d
        Yh_yg = Yh_yg + Gama(j,i)*Y1_test(g+1-j:n-j,:)*Q*C';
    end     
end
% Yh_yg = (Zy*kron(gama,C))*C'; % auto-regressive quality part

X_Alpha = zeros(n-s,m); 
for i = 1:a
    for j = 0:s
        X_Alpha = X_Alpha + Alpha(j+1,i)*X1_test(s+1-j:n-j,:);
    end     
end

Uh_Gama = zeros(n-g,np); 
for i = 1:a
    for j = 1:d
        Uh_Gama = Uh_Gama + Gama(j,i)*Y1_test(g+1-j:n-j,:);
    end     
end

T_dx = zeros(n,a);
for i = 1:n
    x = X1_test(i,:)';
    t_dx = Rx'*x;
    T_dx(i,:) = t_dx';
end

for i = g+1:n
    x = X1_test(i,:)'; 
    y = Y1_test(i,:)';
    
    % T2
    t = R'*x;
    T2_index(i) = t'*inv(Lambda)*t;
    
    % Dynamic Covariance Subspace (DCVS) 
    x_Alpha = X_Alpha(i-g,:)';    
    Tc2_index(i) = x_Alpha'*Rc*inv(Lambda_c)*Rc'*x_Alpha;
    
    % Dynamic Auto-regressive Quality Subspace(DAQS)
    uh_Gama = Uh_Gama(i-g,:)';
    Tdy2_index(i) = uh_Gama'*inv(Lambda_dy)*uh_Gama;
        
    % Static Quality Principal Subspace (SQPS)
    uc = Rc'*x_Alpha;
    yct = y - Yh_xg(i-g,:)' - Yh_yg(i-g,:)';
    t_sy = Py'*yct;
    Tsy2_index(i) = t_sy'*inv(Lambda_sy)*t_sy;    
    
    % Static Quality Resudial Subspace (SQRS)
    Qy_index(i) = yct'*(eye(size(Py*Py')) - Py*Py')*yct;
    
    % Dynamic Process Principal Subspace (DPPS)
    th_dx = 0;
    for j = 1:s
        t_dx = T_dx(i-j+1,:)';
        th_dx = th_dx + Theta_x(j)*t_dx;        
    end        
    
    phi_dx_index(i) = th_dx'*Phi_dx*th_dx;
    
    % Static Process Principal Subspace (SPPS)
    ex = x - P_dx*th_dx;
    t_sx = P_sx'*ex;
    Tsx2_index(i) = t_sx'*inv(Lambda_sx)*t_sx;
    
    % Static Process Residual Subspace (SPRS)
    e_sx = (eye(size(P_sx*P_sx')) - P_sx*P_sx')*ex;
    Qsx_index(i) = e_sx'*e_sx;
    Qdx_index(i) = ex'*ex;
end