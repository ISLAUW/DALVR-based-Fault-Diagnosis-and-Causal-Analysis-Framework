function [ax_pca,ay_pca,Tx,Ty,Px,Py,lamda_x,lamda_y,Tx2_lim,Ty2_lim,Qx_lim,Qy_lim]=PCA_train(X0,Y0)
% This function trains PCA
% X0,Y0 must be autoscaled

[n,~]=size(X0); 
%[ax_pca,lamda_x,Tx,Px]=PCA(X0,0.95);
%[ay_pca,lamda_y,Ty,Py]=PCA(Y0,0.95);
ax_pca = pc_number(X0);
ay_pca = pc_number(Y0);
[Px, lamda_x, Tx2_lim, Qx_lim] = PCA(X0,ax_pca);
[Py, lamda_y, Ty2_lim, Qy_lim] = PCA(Y0,ay_pca);

%% ———— PCA control limit for detection ————
alpha=0.01; level=1-alpha; 
% ———— T2_lim ————
Tx2_lim=(ax_pca*(n^2-1)/(n*(n-ax_pca)))*finv(level,ax_pca,n-ax_pca);
Ty2_lim=(ay_pca*(n^2-1)/(n*(n-ay_pca)))*finv(level,ay_pca,n-ay_pca);

% ———— Q_lim ————
for i=1:n
    x=X0(i,:)'; y=Y0(i,:)';
    xk=(eye(size(Px*Px'))-Px*Px')*x; Qx_index(i)=xk'*xk;
    yk=(eye(size(Py*Py'))-Py*Py')*y; Qy_index(i)=yk'*yk;
end
ax=mean(Qx_index); bx=var(Qx_index); gx=bx/(2*ax); hx=2*ax^2/bx;
ay=mean(Qy_index); by=var(Qy_index); gy=by/(2*ay); hy=2*ay^2/by;
Qx_lim=gx*chi2inv(level,hx);
Qy_lim=gy*chi2inv(level,hy);

[Px, lamda_x, Tx2_lim, Qx_lim] = PCA(X0,ax_pca);
[Py, lamda_y, Ty2_lim, Qy_lim] = PCA(Y0,ay_pca);
Tx = X0*Px;
Ty = Y0*Py;