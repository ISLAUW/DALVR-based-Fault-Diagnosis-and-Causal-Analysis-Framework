function [R,Q,Alpha,P,W,C,Gama,Lambda,M_T2, M_Q, M_phi, ...,
   T2_lim, Q_lim, phi_lim] = darlvr_rbc_train(U1,Y1,U1_test, Y1_test, a,gamma_w,gamma_beta,gamma_delta,s,d)

% this function trains DArLVR
% U1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% U1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of cross-correlations
% d -- the lag parameter to denote the degree of auto-correlations

[n,m] = size(U1); np = size(Y1,2);
nt = size(U1_test,1);
g = max(s,d); N = n - g; Nt = nt - g;


%% ———— DALVR ————
[P,Q,C,W,Alpha,Gama] = darlvr(U1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);
R = W * pinv(P'*W);
T = U1* R;
Lambda = 1/(n-1) * T'* T;

%% ———— Reconstruction-Based Contribution (RBC) ————
alpha = 0.01; level = 1 - alpha;

M_T2 = R * pinv(Lambda) * R'; % T2
M_Q = (eye(size(P*R'))-P*R'); % SPE

% ———— Control Limits ————
T2_lim = chi2inv(level,a); 

Ut_beta = zeros(N, m);
for l = 1:a
    for i = 0:s
        Ut_beta = Ut_beta + Alpha(i+1,l) * U1(g-i+1:g-i+N,:);
    end
end

for k = 1:N
    u = Ut_beta(k,:)';
    Q_index(k) = u'* M_Q * u;
end
a_q = mean(Q_index); b_q = var(Q_index); 
g_q = b_q/(2*a_q); h_q = 2*a_q^2/b_q;
Q_lim = g_q * chi2inv(level,h_q);

M_phi = M_T2/T2_lim + M_Q/Q_lim; % phi

Ut_beta = zeros(Nt,m);
for l = 1:a
    for i = 0:s
        Ut_beta = Ut_beta + Alpha(i+1,l) * U1_test(g-i+1:g-i+Nt,:);
    end
end

S = 1/(Nt-1)* U1_test'* U1_test;

g_phi = trace((S * M_phi)^2)/trace(S * M_phi);
h_phi = (trace(S * M_phi))^2/trace((S * M_phi)^2);
phi_lim = g_phi * chi2inv(level,h_phi);