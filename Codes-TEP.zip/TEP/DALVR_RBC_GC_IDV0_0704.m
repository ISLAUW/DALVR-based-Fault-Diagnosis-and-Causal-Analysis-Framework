clear all
clc
close all
format short;
tic

%% ———— Data ————
% ———— Training Data: IDV(0) ————
%load d00.dat;
% —— Training Data ——
%T = 1; 
%n = size(d00,2)/T;

%X0 = zeros(n,33); Y0 = zeros(n,1); 
%for i = 1:n
    %X0(i,:) = [d00(1:22,(T*i))',d00(42:52,(T*i))']; 
    %Y0(i,:) = d00(35,(T*i))';
%end

%X0 = X0(1:480,:); Y0 = Y0(1:480,:);

% ———— Training Data: IDV(0) ————
load d00_te.dat;
% —— Training Data ——
T0 = 1; 
n = size(d00_te,1)/T0;
X0 = zeros(n,33); Y0 = zeros(n,1); 

for j = 1:n
    X0(j,:) = [d00_te((T0*j),1:22),d00_te((T0*j),42:52)]; 
    Y0(j,:) = d00_te((T0*j),38);    
end

%X0 = X0(1:480,:); Y0 = Y0(1:480,:);

% ———— Testing Data: IDV(0) ————
load d00_te.dat; % 960*52
X0_te = d00_te;

T = 1;
% —— Testing Data Downsampled ——
n_te = size(X0_te,1)/T;
X0_test = zeros(n_te,33); Y0_test=zeros(n_te,1); 
for j = 1:n_te
    X0_test(j,:) = [X0_te((T*j),1:22),X0_te((T*j),42:52)]; 
    Y0_test(j,:) = X0_te((T*j),38);    
end

% ———— Autoscale the training data and testing data ————
[X1,mx_train,vx_train] = autos(X0);
[Y1,my_train,vy_train] = autos(Y0);

X1_test = autos_test(X0_test,mx_train,vx_train);
Y1_test = autos_test(Y0_test,my_train,vy_train);

[n_train,m] = size(X1);
n_test = size(X1_test,1);


figure
plot(X1_test(:,4),'b');
title('Variable 4')

%% ———— Parameter Determination————
load darlvr_factor_data.mat
%a = 2; s = 1; d = 2; gamma_w = 0.001; gamma_beta = 0.001; gamma_delta = 0.001;
%a = 2; s = 1; d = 1; gamma_w = 0.001; gamma_beta = 0.001; gamma_delta = 0.001;

%% ———— DALVR ————
g = max(s,d); 
[P,Q,C,W,Beta,Delta] = darlvr(X1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);

%% ———— Monitoring ————
% ———— Testing Data ————
[T2_index_test, Q_index_test, phi_index_test, T2_lim, Q_lim, phi_lim] ...
    = darlvr_monitoring (X1, Y1, X1_test, Y1_test, a, s, d, P, Q, C, W, Beta, Delta);

% ———— Training Data ————
[T2_index_train, Q_index_train, phi_index_train] ...
    = darlvr_monitoring (X1, Y1, X1, Y1, a, s, d, P, Q, C, W, Beta, Delta);

% ———— Monitoring ————
n_plot = n_test;

figure
subplot(3,1,1)
plot([1:n_plot], [T2_index_test], [1:n_plot], T2_lim * ones(1,n_plot));
title('T^2');
legend('Statistic', 'Control Limit')

subplot(3,1,2)
plot([1:n_plot], [Q_index_test], [1:n_plot], Q_lim * ones(1,n_plot));
title('Q');

subplot(3,1,3)
plot([1:n_plot], [phi_index_test], [1:n_plot], phi_lim * ones(1,n_plot));
title('\phi');

% Combined Index
figure
plot([1:n_plot], [phi_index_test], [1:n_plot], phi_lim * ones(1,n_plot));
title('\phi');
legend('Statistic', 'Control Limit')

%% ———— Reconstruction-Based Contribution ————
[R,Q,Alpha,P,W,C,Gama,Lambda, ksi, RBC_T2_test, RBC_Q_test, RBC_phi_test, RBC_T2_rate, RBC_Q_rate, RBC_phi_rate,RBC_index_T2, RBC_index_Q, RBC_index_phi, ...
   RBC_T2_lim, RBC_Q_lim, RBC_phi_lim] = darlvr_rbc(X1,Y1,X1_test, Y1_test, a,gamma_w,gamma_beta,gamma_delta,s,d);

[~,~,~,~,~,~,~,~,~,RBC_T2_train, RBC_Q_train, RBC_phi_train,~,~,~,~,~,~, ...
   ~,~,~] = darlvr_rbc(X1,Y1,X1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);

%% ———— Contribution Plots ————
%[Cont_T2_test, Cont_Q_test, Cont_phi_test, Cont_T2_lim, Cont_Q_lim, Cont_phi_lim] = darlvr_cont(X1, Y1, X1_test, Y1_test, a, s, d, P, W, Beta);


%% ———— Plotting ————
%k0 = 303;
%k0 = 847;
k0 = 165;

figure
bar(RBC_phi_test(k0,:))
hold on
plot([1:m], RBC_phi_lim)
%title('165^{th}')
legend('RBC','Control limit')
xticks([1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33])
xticklabels({'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33'})
xlabel('No. of Variables'); 



% ———— Combined RBC Index Based on 1 as Control Limit ————
for i = 1:m
    RBC_phi_avg(i) = 1/length(RBC_phi_train) * sum(RBC_phi_train(:,i));
    RBC_phi_relative_test(:,i) = RBC_phi_test(:,i) / RBC_phi_avg(i);    
end

k1 = 120; 
k2 = k1+1; 
k3 = 160; 
k4 = 200;
cl_k1 = 1/3 * max(RBC_phi_relative_test(k1,:));
cl_k2 = 1/3 * max(RBC_phi_relative_test(k2,:));
cl_k3 = 1/3 * max(RBC_phi_relative_test(k3,:));
cl_k4 = 1/3 * max(RBC_phi_relative_test(k4,:));

cl_k0 = 1/3 * max(RBC_phi_relative_test(k0,:));
figure
bar(RBC_phi_relative_test(k0,:))
hold on
plot([1:m], cl_k0 * ones(1,m))
%title('165^{th}')
legend('rRBC','Control limit')
xticks([1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33])
xticklabels({'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33'})
xlabel('No. of Variables'); 


figure
subplot(4,1,1)
bar(RBC_phi_relative_test(k1,:))
hold on
plot([1:m], cl_k1 * ones(1,m))
title('120^{th}')
legend('RBC','Control limit')
%ylim([0 10])

subplot(4,1,2)
bar(RBC_phi_relative_test(k2,:))
hold on
plot([1:m], cl_k2 * ones(1,m))
title('121^{st}')
%ylim([0 10])


subplot(4,1,3)
bar(RBC_phi_relative_test(k3,:))
hold on
plot([1:m], cl_k3 * ones(1,m))
title('160^{th}')
%ylim([0 520])

subplot(4,1,4)
bar(RBC_phi_relative_test(k4,:))
hold on
plot([1:m], cl_k4 * ones(1,m))
title('200^{th}')
%ylim([0 520])

figure
bar(RBC_phi_relative_test(k2,:))
hold on
plot([1:m], cl_k2 * ones(1,m))
%title('165^{th}')
legend('rRBC','Control limit')
xticks([1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33])
xticklabels({'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33'})
xlabel('No. of Variables'); 

figure
bar(RBC_phi_test(k2,:))
hold on
plot([1:m], RBC_phi_lim/1000)
%title('165^{th}')
legend('RBC','Control limit')
xticks([1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33])
xticklabels({'1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33'})
xlabel('No. of Variables'); 

% ———— Output ————
%figure
%plot(Y1_test,'b');
%title('Output')
%legend('predicting data','test data')

%figure 
%subplot(4,1,1)
%plot(X1_test(:,1),'b');
%title('A Feed in Stream 1 (V1)')

%subplot(4,1,2)
%plot(X1_test(:,16),'b');
%title('Stripper Pressure (V16)')

%subplot(4,1,3)
%plot(X1_test(:,18),'b');
%title('Stripper Temperature (V18)')

%subplot(4,1,4)
%plot(X1_test(:,25),'b');
%title('A Feed Flow in Stream 1 (V25)')

%% ———— Time-Domain Granger Causality ————
alpha = 0.01; max_lag = 5;

k = k2;
%k = 200;
%k = 600;

RBC_variables = zeros(0,0);
for i = 1:m
    if RBC_phi_relative_test(k,i) > 1/3 * max(RBC_phi_relative_test(k,:))
        RBC_variables = [RBC_variables i];
    end
end

X0_te_cause = zeros(n_te, length(RBC_variables));
X1_te_cause = zeros(n_te, length(RBC_variables));
for i = 1:length(RBC_variables)
    X0_te_cause(:,i) = X0_test(:,RBC_variables(i));
    X1_te_cause(:,i) = X1_test(:,RBC_variables(i));

end

[variable_osi_0, osi, C, no_cause_x1, no_cause_x2] = Granger_Causality_osi_1 (X0_te_cause, X1_te_cause, Y1_test, alpha, max_lag, a, gamma_w, gamma_beta, gamma_delta, s, d);

for i = 1:length(variable_osi_0)
    variable_osi(i) = RBC_variables(variable_osi_0(i));
end

variable_osi = [15 18 30 33]; % tdgc variables

X0_k = zeros(size(X0_test,1),length(variable_osi));
for i = 1:length(variable_osi)
    X0_k(:,i) = X0_test(:,variable_osi(i));
end

X0_csgc = cell(size(X0_k,2),1);
for i = 1:size(X0_k,2)
    X0_csgc(i,1) = {X0_k(:,i)};
    %X0_csgc(i,1) = {X0_test(:,i)};
end


N = size(X0_csgc, 1);
R = size(X0_csgc, 2);

% calculate CSGC
[CSGC, Fr] =  CalculateCSGC(X0_csgc, 'param', 6, 'order', 1);
%Scale = 1./(Fr*12);
Scale = 1./(Fr*60); % 48h / 3min


% ———— Plot spectrum ————
figure()
for i = 1:length(variable_osi)
    for j = 1:length(variable_osi)
        if i ~=j
            subplot(length(variable_osi), length(variable_osi), (i-1)*length(variable_osi)+j)
            plot(Fr, abs(CSGC{i,j}), 'LineWidth', 1 )
            ylim([0 10])
        end
    end
end


%Colours = {'b', 'r', 'g', 'y', 'm', 'c','k','#0072BD'};
%figure()
%for i1 = 1:(length(variable_osi)-1)
    %plot(Scale, (1-exp(-CSGC{1, i1+1}))*100, [Colours{i1}, '-'], 'linewidth', 2)
    %if i1 == 1
        %hold on
    %end
%end

%set(gca, 'xscale', 'log', 'xtick', [0.01, 0.1, 1],...
%    'xticklabel', {'0.01', '0.1', '1'},...
%    'ylim', [0, 100], 'ytick', 0:20:100)
%set(gca, 'ylim', [0, 100], 'ytick', 0:20:100)
%legend('Variable 3', 'Variable 4', 'Variable 7', 'Variable 8', 'Variable 11', 'Variable 20', 'Variable 27', 'Variable 28')



