function [Y_predict,Yxg_predict,Yyg_predict] = dapls_predict(X1,Y1,X1_test,Y1_test,a,s,d)
% X1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% X1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s, d -- the lag parameter to denote the degree of dynamics
% kappa -- the parameter of regularization term

%[P,Q,C,W,Beta,Delta,Y1_debug] = darlvr(X1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);
[P, Q, C, W, Beta, Delta] = dapls(X1, Y1, a, s, d);

R = W*pinv(P'*W);
[n,m] = size(X1_test); np = size(Y1_test,2);
g = max(s,d); N = n-g; 
Y_predict = zeros(n,np); 
Yxg_predict = zeros(n,np); Yyg_predict = zeros(n,np);

for l = 1:a
    T = X1_test*R;
    t = T(:,l);
    
    Ts = zeros(N,s+1);
    for i = 0:s
        Ts(:,i+1) = t(s-i+1:s-i+N,:);
    end
    
    q = Q(:,l);
    u = Y1_test*q;
    Ud = zeros(N,d);
    for i = 1:d
        Ud(:,i) = u(g-i+1:g-i+N,:);
    end
    
    delta = Delta(:,l);
    beta = Beta(:,l);
    
    ug_t = Ts*beta;
    ug_u = Ud*delta;
    ug_hat = ug_u + ug_t;
    
    %Y_predict(1:g,:) = Y_predict(1:g,:) + t(1:g)*C(:,l)';
    %Yxg_predict(1:g,:) = Yxg_predict(1:g,:) + t(1:g)*C(:,l)';
    %Yyg_predict(1:g,:) = Yyg_predict(1:g,:) + t(1:g)*C(:,l)';
    
    Y_predict(g+1:end,:) = Y_predict(g+1:end,:) + ug_hat*C(:,l)';
    Yxg_predict(g+1:end,:) = Yxg_predict(g+1:end,:) + ug_t*C(:,l)';
    Yyg_predict(g+1:end,:) = Yyg_predict(g+1:end,:) + ug_u*C(:,l)';
end
