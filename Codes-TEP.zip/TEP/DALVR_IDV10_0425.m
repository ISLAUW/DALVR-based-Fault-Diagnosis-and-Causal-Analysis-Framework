clear all
clc
close all
format short;
tic

%% ———— Data ————
% ———— Training Data: IDV(0) ————
load d00.dat;
%load d00_te.dat;
% —— Training Data ——
T0 = 5; 
n = size(d00,2)/T0;
%n = size(d00_te,1)/T0;
X0 = zeros(n,33); Y0 = zeros(n,1); 

for j = 1:n
    X0(j,:) = [d00(1:22,(T0*j-2))',d00(42:52,(T0*j-2))']; 
    Y0(j,:) = d00(38,(T0*j-2))';    
end

%for j = 1:n
%    X0(j,:) = [d00_te((T0*j-4),1:22),d00_te((T0*j-4),42:52)]; 
%    Y0(j,:) = d00_te((T0*j-4),38);    
%end

% ———— Testing Data: IDV(10) ————
load d10_te.dat; % 960*52
X0_te = d10_te;

T = 5;
% —— Testing Data Downsampled ——
n_te = size(X0_te,1)/T;
X0_test = zeros(n_te,33); Y0_test=zeros(n_te,1); 
for j = 1:n_te
    X0_test(j,:) = [X0_te((T*j-4),1:22),X0_te((T*j-4),42:52)]; 
    Y0_test(j,:) = X0_te((T*j-4),38);    
end

% ———— Autoscale the training data and testing data ————
[X1,mx_train,vx_train] = autos(X0);
[Y1,my_train,vy_train] = autos(Y0);

X1_test = autos_test(X0_test,mx_train,vx_train);
Y1_test = autos_test(Y0_test,my_train,vy_train);

[n_train,m] = size(X1);
n_test = size(X1_test,1);

%figure
%plot(X1_test(:,4),'b');
%title('Variable 4')

%% ———— Parameter Determination————
load darlvr_factor_data.mat
%a = 1; s = 1; d = 1; gamma_w = 0.005; gamma_beta = 0.005; gamma_delta = 0.005; 

%% ———— DrLVR-ARX ————
g = max(s,d); 
[P,Q,C,W,Beta,Delta] = darlvr(X1,Y1,a,gamma_w,gamma_beta,gamma_delta,s,d);

% ———— MSE ————
[Y1_predict,Y1xg_predict,Y1yg_predict] = darlvr_predict(X1,Y1,X1_test,Y1_test,a,gamma_w,gamma_beta,gamma_delta,s,d);
[MSE_Y1,MSE_Y1xg,MSE_Y1yg] = darlvr_mse(X1,Y1,X1_test,Y1_test,a,gamma_w,gamma_beta,gamma_delta,s,d);


%% ———— DrLVR-ARX-Based Monitoring ————
% ———— Testing Data ————
[T2_index_test, Q_index_test, phi_index_test, T2_lim, Q_lim, phi_lim] ...
    = darlvr_monitoring (X1, Y1, X1_test, Y1_test, a, s, d, P, Q, C, W, Beta, Delta);

% ———— Training Data ————
[T2_index_train, Q_index_train, phi_index_train] ...
    = darlvr_monitoring (X1, Y1, X1, Y1, a, s, d, P, Q, C, W, Beta, Delta);


%% ———— DrLVR ————
a1 = 1;
s1 = 3;
kappa = 0.005;

% ———— DrLVR training ————
[R,B1,Q,A,P,W,C,lamda_theta,T2_lim_drlvr,Q_lim_drlvr] = drlvr_train(X1,Y1,a1,s1,kappa);

% ———— MSE ————
% [B1,Q,A,P,W,C] = drlvr(X1,Y1,a,s,kappa);
Y_predict_drlvr = drlvr_predict(X1,Y1,X1_test,Y1_test,a1,s1,kappa);
MSE_drlvr = drlvr_mse(X1,Y1,X1_test,Y1_test,a1,s1,kappa);

%% ———— DrLVR-Based Monitoring ————
% ———— Obtain the indices for the testing data ————
[T2_index_test_drlvr,Q_index_test_drlvr] = drlvr_test(X1_test,Y1_test,a1,s1,kappa,R,B1,Q,A,P,W,C,lamda_theta,T2_lim_drlvr,Q_lim_drlvr);
% ———— Obtain the indices for the training data ————
[T2_index_train_drlvr,Q_index_train_drlvr] = drlvr_test(X1,Y1,a1,s1,kappa,R,B1,Q,A,P,W,C,lamda_theta,T2_lim_drlvr,Q_lim_drlvr);


%% ———— rLVR ————
a_rLVR = 1;
k_rLVR = 0.005; % reguralization term

MSE_rLVR = rlvr_mse(X1, Y1, X1_test, Y1_test, a_rLVR, k_rLVR);

% ———— rLVR training ————
[R_rLVR, T_rLVR, P_rLVR, Q_rLVR, lamda_rLVR, ~, ~, ~, T2_lim_rlvr, Q_lim_rlvr] = rlvr_train(X1, Y1, a_rLVR, k_rLVR);

%% ———— rLVR-Based Monitoring ————
% ———— Obtain the indices for the testing data ————
[T2_index_test_rlvr, Q_index_test_rlvr] = rlvr_test(X1_test, Y1_test, R_rLVR, T_rLVR, P_rLVR, Q_rLVR, T2_lim_rlvr, Q_lim_rlvr);

% ———— Obtain the indices for the training data ————
[T2_index_train_rlvr, Q_index_train_rlvr] = rlvr_test(X1, Y1, R_rLVR, T_rLVR, P_rLVR, Q_rLVR, T2_lim_rlvr, Q_lim_rlvr);


%% ———— DAPLS ————
a_dapls = 3;
s_dapls = 3;
d_dapls = 1;

[P_dapls, Q_dapls, C_dapls, W_dapls, Beta_dapls, Delta_dapls] = dapls(X1, Y1, a_dapls, s_dapls, d_dapls);
% ———— MSE ————
[MSE_Y1_dapls,MSE_Y1xg_dapls,MSE_Y1yg_dapls] = dapls_mse(X1,Y1,X1_test,Y1_test,a_dapls,s_dapls,d_dapls);

%% ———— DAPLS-Based Monitoring ————
% ———— Testing Data ————
[T2_index_test_dapls, Q_index_test_dapls, phi_index_test_dapls, T2_lim_dapls, Q_lim_dapls, phi_lim_dapls] ...
    = dapls_monitoring (X1, Y1, X1_test, Y1_test, a_dapls, s_dapls, d_dapls, P_dapls, Q_dapls, C_dapls, W_dapls, Beta_dapls, Delta_dapls);
% ———— Training Data ————
[T2_index_train_dapls, Q_index_train_dapls, phi_index_train_dapls] ...
    = dapls_monitoring (X1, Y1, X1, Y1, a_dapls, s_dapls, d_dapls, P_dapls, Q_dapls, C_dapls, W_dapls, Beta_dapls, Delta_dapls);

%% ———— Plotting ————
n_plot = n_test;

% ———— MSE ————
figure;
subplot(3,1,1);
plot(Y1_predict,'r', 'LineWidth', 1.5);
hold on
plot(Y1_test,'b', 'LineWidth', 1.5);
title('DrLVR-ARX')
legend('Y predict','Y test')

subplot(3,1,2);
plot(Y1xg_predict,'r', 'LineWidth', 1.5);
hold on
plot(Y1_test,'b', 'LineWidth', 1.5);
title('Cross-correlation part of DrLVR-ARX')

subplot(3,1,3);
plot(Y1yg_predict,'r', 'LineWidth', 1.5);
hold on
plot(Y1_test,'b', 'LineWidth', 1.5);
title('Auto-correlation part of DrLVR-ARX')


figure
subplot(2,1,1)
plot([1:n_plot], Y1_predict, [1:n_plot], Y1_test, 'LineWidth', 1.5);
title('DrLVR-ARX');
legend('Predictions', 'Actual Variations')

subplot(2,1,2)
plot([1:n_plot], Y_predict_drlvr, [1:n_plot], Y1_test, 'LineWidth', 1.5);
title('DrLVR');

% ———— Monitoring ————
% ———— rLVR ————
figure
subplot(2,1,1)
plot([1:n_plot], [T2_index_test_rlvr], [1:n_plot], T2_lim_rlvr * ones(1,n_plot), 'LineWidth', 1);
title('T^2');
legend('Statistic', 'Control Limit')

subplot(2,1,2)
plot([1:n_plot], [Q_index_test_rlvr], [1:n_plot], Q_lim_rlvr * ones(1,n_plot), 'LineWidth', 1);
title('Q');

% —— DrLVR-ARX ——
figure
subplot(3,1,1)
plot([1:n_plot], [T2_index_test], [1:n_plot], T2_lim * ones(1,n_plot));
title('T^2');
legend('Statistic', 'Control Limit')

subplot(3,1,2)
plot([1:n_plot], [Q_index_test], [1:n_plot], Q_lim * ones(1,n_plot));
title('Q');

subplot(3,1,3)
plot([1:n_plot], [phi_index_test], [1:n_plot], phi_lim * ones(1,n_plot));
title('\phi');

% —— DrLVR ——
figure
subplot(2,1,1)
plot([1:n_plot], [T2_index_test], [1:n_plot], T2_lim * ones(1,n_plot), 'LineWidth', 1);
title('T^2');
legend('Statistic', 'Control Limit')

subplot(2,1,2)
plot([1:n_plot], [Q_index_test], [1:n_plot], Q_lim * ones(1,n_plot), 'LineWidth', 1);
title('Q');


% Combined Index
figure
plot([1:n_plot], [phi_index_test], [1:n_plot], phi_lim * ones(1,n_plot), 'LineWidth', 1);
title('\phi');
legend('Statistic', 'Control Limit')

% DrLVR
figure
subplot(2,1,1)
plot([1:n_plot], [T2_index_test_drlvr], [1:n_plot], T2_lim * ones(1,n_plot), 'LineWidth', 1);
title('T^2');
legend('Statistic', 'Control Limit')

subplot(2,1,2)
plot([1:n_plot], [Q_index_test_drlvr], [1:n_plot], Q_lim * ones(1,n_plot), 'LineWidth', 1);
title('Q');

%% —————— PCA-based monitoring on X & Y——————
% ———— PCA Training ————
[ax_pca,ay_pca,Tx_pca,Ty_pca,Px_pca,Py_pca,lamda_x_pca,lamda_y_pca,Tx2_lim_pca,Ty2_lim_pca,Qx_lim_pca,Qy_lim_pca]=PCA_train(X1,Y1);

% ———— PCA Testing ————
% —— Obtain the indices for the testing data ——
[Tx2_index_pca_train,Ty2_index_pca_train,Qx_index_pca_train,Qy_index_pca_train] = PCA_test(X1,Y1,Tx_pca,Ty_pca,Px_pca,Py_pca,lamda_x_pca,lamda_y_pca);
% —— Obtain the indices for the training data ——
[Tx2_index_pca_test,Ty2_index_pca_test,Qx_index_pca_test,Qy_index_pca_test] = PCA_test(X1_test,Y1_test,Tx_pca,Ty_pca,Px_pca,Py_pca,lamda_x_pca,lamda_y_pca);


figure
subplot(3,1,1)
plot([1:n_plot], [Ty2_index_pca_test], [1:n_plot], Ty2_lim_pca * ones(1,n_plot));
title('T_y^2');
legend('Statistic', 'Control Limit')

subplot(3,1,2)
plot([1:n_plot], [Tx2_index_pca_test], [1:n_plot], Tx2_lim_pca * ones(1,n_plot));
title('T_x^2');

subplot(3,1,3)
plot([1:n_plot], [Qx_index_pca_test], [1:n_plot], Qx_lim_pca * ones(1,n_plot));
title('Q_x');

%% ———— Fault Detection Rate (FDR) & Missing Alarm Rate (MAR) & Fault Alarm Rate (FAR) ————        
% DrLVR-ARX
% ———— T2 ————
TP_T2=zeros(size(X1_test,1),1);
TN_T2=zeros(size(X1_test,1),1);
FP_T2=zeros(size(X1_test,1),1);
FN_T2=zeros(size(X1_test,1),1);

for count=1:size(X1_test,1)
    if T2_index_test(count)>T2_lim && Ty2_index_pca_test(count)>Ty2_lim_pca
        TP_T2(count)=1;
    elseif T2_index_test(count)<T2_lim && Ty2_index_pca_test(count)<Ty2_lim_pca
        TN_T2(count)=1;
    elseif T2_index_test(count)>T2_lim && Ty2_index_pca_test(count)<Ty2_lim_pca
        FP_T2(count)=1;
    elseif T2_index_test(count)<T2_lim && Ty2_index_pca_test(count)>Ty2_lim_pca
        FN_T2(count)=1;
    end
end

if sum(TP_T2)==0 && sum(FN_T2)==0
    FDR_T2 = 0
    MAR_T2 = 0;
    AR_T2 = 0    % Accurate rate
    PR_T2 = 0    % Precision rate
    TPR_T2 = 0;   % Ture positive rate
    
else
    FDR_T2 = sum(TP_T2) / (sum(TP_T2) + sum(FN_T2))
    MAR_T2 = sum(FN_T2) / (sum(TP_T2) + sum(FN_T2));
    AR_T2 = (sum(TP_T2) + sum(TN_T2)) / (sum(TP_T2) + sum(TN_T2) + sum(FP_T2) + sum(FN_T2))
    PR_T2 = sum(TP_T2) / (sum(TP_T2) + sum(FP_T2))
    TPR_T2 = sum(TP_T2) / (sum(TP_T2) + sum(FN_T2));
    
end

if sum(FP_T2)==0 && sum(TN_T2)==0
    FAR_T2 = 0
    FPR_T2 = 0;   % False positive rate
else
    FAR_T2 = sum(FP_T2) / (sum(FP_T2)+sum(TN_T2))
    FPR_T2 = sum(FP_T2) / (sum(FP_T2) + sum(TN_T2));
end



% DrLVR
% ———— T2 ————
TP_T2_drlvr=zeros(size(X1_test,1),1);
TN_T2_drlvr=zeros(size(X1_test,1),1);
FP_T2_drlvr=zeros(size(X1_test,1),1);
FN_T2_drlvr=zeros(size(X1_test,1),1);

for count=1:size(X1_test,1)
    if T2_index_test_drlvr(count)>T2_lim_drlvr && Ty2_index_pca_test(count)>Ty2_lim_pca
        TP_T2_drlvr(count)=1;
    elseif T2_index_test_drlvr(count)<T2_lim_drlvr && Ty2_index_pca_test(count)<Ty2_lim_pca
        TN_T2_drlvr(count)=1;
    elseif T2_index_test_drlvr(count)>T2_lim_drlvr && Ty2_index_pca_test(count)<Ty2_lim_pca
        FP_T2_drlvr(count)=1;
    elseif T2_index_test_drlvr(count)<T2_lim_drlvr && Ty2_index_pca_test(count)>Ty2_lim_pca
        FN_T2_drlvr(count)=1;
    end
end

if sum(TP_T2_drlvr)==0 && sum(FN_T2_drlvr)==0
    FDR_T2_drlvr=0
    MAR_T2_drlvr=0;
    AR_T2_drlvr = 0    % Accurate rate
    PR_T2_drlvr = 0    % Precision rate
    TPR_T2_drlvr = 0;   % Ture positive rate
else
    FDR_T2_drlvr = sum(TP_T2_drlvr)/(sum(TP_T2_drlvr)+sum(FN_T2_drlvr))
    MAR_T2_drlvr = sum(FN_T2_drlvr)/(sum(TP_T2_drlvr)+sum(FN_T2_drlvr));
    AR_T2_drlvr = (sum(TP_T2_drlvr) + sum(TN_T2_drlvr)) / (sum(TP_T2_drlvr) + sum(TN_T2_drlvr) + sum(FP_T2_drlvr) + sum(FN_T2_drlvr))
    PR_T2_drlvr = sum(TP_T2_drlvr) / (sum(TP_T2_drlvr) + sum(FP_T2_drlvr))
    TPR_T2_drlvr = sum(TP_T2_drlvr) / (sum(TP_T2_drlvr) + sum(FN_T2_drlvr));
end

if sum(FP_T2_drlvr)==0 && sum(TN_T2_drlvr)==0
    FAR_T2_drlvr=0
    FPR_T2_drlvr = 0;   % False positive rate
else
    FAR_T2_drlvr=sum(FP_T2_drlvr)/(sum(FP_T2_drlvr)+sum(TN_T2_drlvr))
    FPR_T2_drlvr = sum(FP_T2_drlvr) / (sum(FP_T2_drlvr) + sum(TN_T2_drlvr));
end

% rLVR
% ———— T2 ————
TP_T2_rlvr=zeros(size(X1_test,1),1);
TN_T2_rlvr=zeros(size(X1_test,1),1);
FP_T2_rlvr=zeros(size(X1_test,1),1);
FN_T2_rlvr=zeros(size(X1_test,1),1);

for count=1:size(X1_test,1)
    if T2_index_test_rlvr(count)>T2_lim_rlvr && Ty2_index_pca_test(count)>Ty2_lim_pca
        TP_T2_rlvr(count)=1;
    elseif T2_index_test_rlvr(count)<T2_lim_rlvr && Ty2_index_pca_test(count)<Ty2_lim_pca
        TN_T2_rlvr(count)=1;
    elseif T2_index_test_rlvr(count)>T2_lim_rlvr && Ty2_index_pca_test(count)<Ty2_lim_pca
        FP_T2_rlvr(count)=1;
    elseif T2_index_test_rlvr(count)<T2_lim_rlvr && Ty2_index_pca_test(count)>Ty2_lim_pca
        FN_T2_rlvr(count)=1;
    end
end

if sum(TP_T2_rlvr)==0 && sum(FN_T2_rlvr)==0
    FDR_T2_rlvr=0
    MAR_T2_rlvr=0;
    AR_T2_rlvr = 0    % Accurate rate
    PR_T2_rlvr = 0    % Precision rate
    TPR_T2_rlvr = 0;   % Ture positive rate
else
    FDR_T2_rlvr = sum(TP_T2_rlvr)/(sum(TP_T2_rlvr)+sum(FN_T2_rlvr))
    MAR_T2_rlvr = sum(FN_T2_rlvr)/(sum(TP_T2_rlvr)+sum(FN_T2_rlvr));
    AR_T2_rlvr = (sum(TP_T2_rlvr) + sum(TN_T2_rlvr)) / (sum(TP_T2_rlvr) + sum(TN_T2_rlvr) + sum(FP_T2_rlvr) + sum(FN_T2_rlvr))
    PR_T2_rlvr = sum(TP_T2_rlvr) / (sum(TP_T2_rlvr) + sum(FP_T2_rlvr))
    TPR_T2_rlvr = sum(TP_T2_rlvr) / (sum(TP_T2_rlvr) + sum(FN_T2_rlvr));
end

if sum(FP_T2_rlvr)==0 && sum(TN_T2_rlvr)==0
    FAR_T2_rlvr=0
    FPR_T2_rlvr = 0;   % False positive rate
else
    FAR_T2_rlvr=sum(FP_T2_rlvr)/(sum(FP_T2_rlvr)+sum(TN_T2_rlvr))
    FPR_T2_rlvr = sum(FP_T2_rlvr) / (sum(FP_T2_rlvr) + sum(TN_T2_rlvr));
end

% DAPLS
% ———— T2 ————
TP_T2_dapls=zeros(size(X1_test,1),1);
TN_T2_dapls=zeros(size(X1_test,1),1);
FP_T2_dapls=zeros(size(X1_test,1),1);
FN_T2_dapls=zeros(size(X1_test,1),1);

for count=1:size(X1_test,1)
    if T2_index_test_dapls(count)>T2_lim_dapls && Ty2_index_pca_test(count)>Ty2_lim_pca
        TP_T2_dapls(count)=1;
    elseif T2_index_test_dapls(count)<T2_lim_dapls && Ty2_index_pca_test(count)<Ty2_lim_pca
        TN_T2_dapls(count)=1;
    elseif T2_index_test_dapls(count)>T2_lim_dapls && Ty2_index_pca_test(count)<Ty2_lim_pca
        FP_T2_dapls(count)=1;
    elseif T2_index_test_dapls(count)<T2_lim_dapls && Ty2_index_pca_test(count)>Ty2_lim_pca
        FN_T2_dapls(count)=1;
    end
end

if sum(TP_T2_dapls)==0 && sum(FN_T2_dapls)==0
    FDR_T2_dapls=0
    MAR_T2_dapls=0;
    AR_T2_dapls = 0    % Accurate rate
    PR_T2_dapls = 0    % Precision rate
    TPR_T2_dapls = 0;   % Ture positive rate
else
    FDR_T2_dapls = sum(TP_T2_dapls)/(sum(TP_T2_dapls)+sum(FN_T2_dapls))
    MAR_T2_dapls = sum(FN_T2_dapls)/(sum(TP_T2_dapls)+sum(FN_T2_dapls));
    AR_T2_dapls = (sum(TP_T2_dapls) + sum(TN_T2_dapls)) / (sum(TP_T2_dapls) + sum(TN_T2_dapls) + sum(FP_T2_dapls) + sum(FN_T2_dapls))
    PR_T2_dapls = sum(TP_T2_dapls) / (sum(TP_T2_dapls) + sum(FP_T2_dapls))
    TPR_T2_dapls = sum(TP_T2_dapls) / (sum(TP_T2_dapls) + sum(FN_T2_dapls));
end

if sum(FP_T2_dapls)==0 && sum(TN_T2_dapls)==0
    FAR_T2_dapls=0
    FPR_T2_dapls = 0;   % False positive rate
else
    FAR_T2_dapls=sum(FP_T2_dapls)/(sum(FP_T2_dapls)+sum(TN_T2_dapls))
    FPR_T2_dapls = sum(FP_T2_dapls) / (sum(FP_T2_dapls) + sum(TN_T2_dapls));
end