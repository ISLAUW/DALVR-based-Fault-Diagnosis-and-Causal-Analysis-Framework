function mse=drlvr_mse(X1,Y1,X1_test,Y1_test,a,s,kappa)
% X1 -- autoscaled input matrix of training data
% Y1 -- autoscaled output matrix of training data
% X1_test -- autoscaled input matrix of testing data
% a -- the number of principal components determined by cross-validation
% s -- the lag parameter to denote the degree of dynamics
% kappa -- the parameter of regularization term

Y_predict=drlvr_predict(X1,Y1,X1_test,Y1_test,a,s,kappa);
Y_error=Y1_test-Y_predict;
mse=sum(sum(Y_error.^2))/size(Y_predict,1);